import type { User, Task, Event, Community, CommunityPost } from "@/types"

export const mockUser: User = {
  id: "1",
  name: "Alex Johnson",
  email: "alex.j@example.com",
  avatar: "/IMG_2464.png",
  gpa: 3.85,
  standardizedScores: {
    sat: 1520,
    act: 34,
    ap: [
      { subject: "Calculus BC", score: 5 },
      { subject: "Physics C: Mechanics", score: 5 },
      { subject: "Chemistry", score: 4 },
      { subject: "English Literature", score: 4 },
    ],
  },
  achievements: [
    {
      id: "ach1",
      title: "Science Fair Winner",
      description: "1st place at State Science Fair for project on renewable energy.",
      icon: "award",
      dateEarned: "2023-05-15",
      category: "academic",
    },
    {
      id: "ach2",
      title: "Debate Team Captain",
      description: "Led the school debate team to regional finals.",
      icon: "users",
      dateEarned: "2023-03-20",
      category: "personal",
    },
  ],
  activities: [
    {
      id: "act1",
      name: "Varsity Soccer",
      category: "sports",
      description: "Starting forward for the varsity soccer team.",
      startDate: "2022-08-25",
      hours: 10,
      position: "Forward",
    },
    {
      id: "act2",
      name: "Coding Club",
      category: "clubs",
      description: "Developed a mobile app for school event notifications.",
      startDate: "2022-09-10",
      hours: 5,
      position: "Lead Developer",
    },
    {
      id: "act3",
      name: "Hospital Volunteer",
      category: "volunteer",
      description: "Assisted patients and staff at the local hospital.",
      startDate: "2023-06-01",
      hours: 8,
    },
  ],
  academics: [
    { id: "acad1", subject: "AP Calculus BC", grade: "A", credits: 5, term: "Fall", year: 2023 },
    { id: "acad2", subject: "AP Physics C", grade: "A-", credits: 5, term: "Fall", year: 2023 },
    { id: "acad3", subject: "Honors English", grade: "A", credits: 4, term: "Fall", year: 2023 },
  ],
  competitions: [
    {
      id: "comp1",
      name: "State Science Fair",
      category: "Science",
      placement: "1st Place",
      date: "2023-05-15",
      description: "Project on optimizing solar panel efficiency.",
    },
    {
      id: "comp2",
      name: "Math Olympiad",
      category: "Mathematics",
      placement: "Top 10 Finalist",
      date: "2023-04-22",
      description: "Competed against top students in the state.",
    },
  ],
  comments: [
    {
      id: "com1",
      author: "Mr. Davison",
      role: "teacher",
      content: "Alex shows exceptional promise in STEM fields. His science fair project was university-level work.",
      date: "2023-05-20",
      sentiment: "positive",
    },
    {
      id: "com2",
      author: "Dr. Emily Carter",
      role: "mentor",
      content:
        "We should work on balancing the academic workload with extracurriculars to avoid burnout. Let's discuss time management strategies.",
      date: "2023-05-18",
      sentiment: "constructive",
    },
  ],
  progressLevel: 75,
  totalPoints: 1250,
  streak: 15,
  joinedDate: "2022-08-15",
}

export const mockTasks: Task[] = [
  {
    id: "task1",
    title: "Complete Calculus homework",
    description: "Chapter 5, problems 1-20.",
    dueDate: "2024-07-28",
    priority: "high",
    category: "academic",
    completed: false,
    createdAt: "2024-07-25",
  },
  {
    id: "task2",
    title: "Draft college essay for Stanford",
    description: 'Focus on the "what matters to you" prompt.',
    dueDate: "2024-08-05",
    priority: "high",
    category: "personal",
    completed: false,
    createdAt: "2024-07-20",
  },
  {
    id: "task3",
    title: "Practice soccer drills",
    description: "Work on dribbling and shooting accuracy.",
    dueDate: "2024-07-29",
    priority: "medium",
    category: "extracurricular",
    completed: true,
    createdAt: "2024-07-24",
  },
  {
    id: "task4",
    title: "Study for Physics quiz",
    description: "Review concepts of kinematics and dynamics.",
    dueDate: "2024-08-01",
    priority: "medium",
    category: "academic",
    completed: false,
    createdAt: "2024-07-26",
  },
]

export const mockEvents: Event[] = [
  {
    id: "event1",
    title: "Calculus Study Group",
    description: "Library, Room 201",
    date: "2024-07-27",
    time: "15:00",
    type: "meeting",
    priority: "medium",
  },
  {
    id: "event2",
    title: "Science Fair Application Deadline",
    description: "Submit project proposal online.",
    date: "2024-08-10",
    time: "23:59",
    type: "deadline",
    priority: "high",
  },
  {
    id: "event3",
    title: "Soccer Game vs. Northwood High",
    description: "Away game.",
    date: "2024-08-02",
    time: "18:00",
    type: "competition",
    priority: "medium",
  },
]

export const mockCommunities: Community[] = [
  {
    id: "comm1",
    name: "College Applicants 2025",
    description: "For students applying to college in 2025.",
    members: 1200,
    category: "Academics",
    avatar:
      "https://images.pexels.com/photos/207692/pexels-photo-207692.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    joined: true,
  },
  {
    id: "comm2",
    name: "STEM Enthusiasts",
    description: "A hub for science, tech, engineering, and math lovers.",
    members: 850,
    category: "STEM",
    avatar:
      "https://images.pexels.com/photos/5071173/pexels-photo-5071173.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    joined: false,
  },
  {
    id: "comm3",
    name: "Student Athletes",
    description: "Balancing sports and academics.",
    members: 2300,
    category: "Sports",
    avatar:
      "https://images.pexels.com/photos/1263349/pexels-photo-1263349.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    joined: true,
  },
]

export const mockPosts: CommunityPost[] = [
  {
    id: "post1",
    title: "Anyone else struggling with the Common App essay?",
    content: "I've been staring at a blank page for hours. Any tips for getting started and finding a unique topic?",
    author: "Sarah K.",
    authorAvatar: "/IMG_2464.png",
    community: "College Applicants 2025",
    communityId: "comm1",
    createdAt: "2024-07-25T10:00:00Z",
    upvotes: 42,
    downvotes: 2,
    comments: [
      {
        id: "p1c1",
        content: "Try brainstorming by just writing down random memories!",
        author: "Mike P.",
        authorAvatar: "/IMG_2464.png",
        date: "2024-07-25T10:05:00Z",
        upvotes: 5,
      },
    ],
    tags: ["essay", "common-app", "writing-block"],
  },
  {
    id: "post2",
    title: "Best resources for AP Physics C prep?",
    content:
      "I'm self-studying for the exam next year and looking for the best textbooks and online resources. What worked for you all?",
    author: "David L.",
    authorAvatar: "/IMG_2464.png",
    community: "STEM Enthusiasts",
    communityId: "comm2",
    createdAt: "2024-07-24T14:30:00Z",
    upvotes: 78,
    downvotes: 1,
    comments: [],
    tags: ["ap-physics", "studying", "resources"],
  },
]
